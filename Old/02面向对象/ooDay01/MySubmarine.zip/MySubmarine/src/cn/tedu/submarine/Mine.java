package cn.tedu.submarine;
/** 水雷 */
public class Mine {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("水雷移动");
    }
}

















