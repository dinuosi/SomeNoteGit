package cn.tedu.submarine;
/** 鱼雷 */
public class Torpedo {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("鱼雷移动");
    }
}
