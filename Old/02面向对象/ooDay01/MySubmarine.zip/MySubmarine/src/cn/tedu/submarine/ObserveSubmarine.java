package cn.tedu.submarine;
/** 侦察潜艇 */
public class ObserveSubmarine {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("侦察潜艇移动");
    }
}

















