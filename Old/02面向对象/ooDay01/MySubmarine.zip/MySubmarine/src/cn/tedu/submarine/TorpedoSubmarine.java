package cn.tedu.submarine;
/** 鱼雷潜艇 */
public class TorpedoSubmarine {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("鱼雷潜艇移动");
    }
}














