package cn.tedu.submarine;
/** 深水炸弹 */
public class Bomb {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("深水炸弹移动");
    }
}













