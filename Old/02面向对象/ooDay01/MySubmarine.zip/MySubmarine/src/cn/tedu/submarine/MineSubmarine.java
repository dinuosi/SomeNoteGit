package cn.tedu.submarine;
/** 水雷潜艇 */
public class MineSubmarine {
    int width;
    int height;
    int x;
    int y;
    int speed;

    void move(){
        System.out.println("水雷潜艇移动");
    }
}
