package cn.tedu.submarine;
/** 战舰 */
public class Battleship {
    int width;  //宽
    int height; //高
    int x;      //x坐标
    int y;      //y坐标
    int speed;  //移动速度
    int life;   //命

    /** 移动 */
    void move(){
        System.out.println("战舰移动");
    }
}

















