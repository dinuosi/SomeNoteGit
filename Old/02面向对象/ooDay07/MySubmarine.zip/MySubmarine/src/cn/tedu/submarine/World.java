package cn.tedu.submarine;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;
import java.util.Arrays;
/** 整个游戏世界 */
public class World extends JPanel {
    public static final int WIDTH = 641;
    public static final int HEIGHT = 479;

    private Battleship ship = new Battleship(); //战舰
    private SeaObject[] submarines = {}; //潜艇(侦察潜艇、鱼雷潜艇、水雷潜艇)数组
    private SeaObject[] thunders = {}; //雷(鱼雷、水雷)数组
    private Bomb[] bombs = {}; //深水炸弹数组

    /** 生成潜艇(侦察潜艇、鱼雷潜艇、水雷潜艇)对象 */
    public SeaObject nextSubmarine(){
        Random rand = new Random(); //随机数对象
        int type = rand.nextInt(20); //0到19之间的随机数
        if(type<10){ //0到9时，返回侦察潜艇对象
            return new ObserveSubmarine();
        }else if(type<15){ //10到14时，返回鱼雷潜艇对象
            return new TorpedoSubmarine();
        }else{ //15到19时，返回水雷潜艇对象
            return new MineSubmarine();
        }
    }

    private int subEnterIndex = 0; //潜艇入场计数
    /** 潜艇(侦察潜艇、鱼雷潜艇、水雷潜艇)入场 */
    public void submarineEnterAction(){ //每10毫秒走一次
        subEnterIndex++; //每10毫秒增1
        if(subEnterIndex%40==0){ //每400(40*10)毫秒走一次
            SeaObject obj = nextSubmarine(); //获取潜艇对象
            submarines = Arrays.copyOf(submarines,submarines.length+1); //扩容
            submarines[submarines.length-1] = obj; //将obj添加到submarines的最后一个元素上
        }
    }

    private int thunderEnterIndex = 0; //雷入场计数
    /** 雷(鱼雷、水雷)入场 */
    public void thunderEnterAction(){ //每10毫秒走一次
        thunderEnterIndex++; //每10毫秒增1
        if(thunderEnterIndex%100==0){ //每1000(10*100)毫秒走一次
            for(int i=0;i<submarines.length;i++){ //遍历所有潜艇
                SeaObject obj = submarines[i].nextThunder(); //获取雷对象
                if(obj!=null){ //若有雷
                    thunders = Arrays.copyOf(thunders,thunders.length+1); //扩容
                    thunders[thunders.length-1] = obj; //将obj装到thunders的末尾
                }
            }
        }
    }

    /** 海洋对象移动 */
    public void moveAction(){ //每10毫秒走一次
        for(int i=0;i<submarines.length;i++){
            submarines[i].move();
        }
        for(int i=0;i<thunders.length;i++){
            thunders[i].move();
        }
        for(int i=0;i<bombs.length;i++){
            bombs[i].move();
        }
    }

    /** 启动程序的执行 */
    public void action(){
        Timer timer = new Timer(); //定时器对象
        int interval = 10; //定时间隔(以毫秒为单位)
        timer.schedule(new TimerTask() {
            public void run() { //定时干的事(每10毫秒自动执行)
                submarineEnterAction(); //潜艇入场
                thunderEnterAction();   //雷入场
                moveAction();           //海洋对象移动
                repaint(); //重画(系统默认重新调用paint()方法)
            }
        }, interval, interval); //定时计划
    }

    /** 重写paint()画 g:画笔 */
    public void paint(Graphics g){ //每10毫秒走一次
        Images.sea.paintIcon(null,g,0,0); //画海洋图
        ship.paintImage(g); //画战舰
        for(int i=0;i<submarines.length;i++){ //遍历所有潜艇
            submarines[i].paintImage(g); //画潜艇
        }
        for(int i=0;i<thunders.length;i++){ //遍历所有雷
            thunders[i].paintImage(g); //画雷
        }
        for(int i=0;i<bombs.length;i++){ //遍历所有深水炸弹
            bombs[i].paintImage(g); //画深水炸弹
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        World world = new World();
        world.setFocusable(true);
        frame.add(world);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(World.WIDTH+16, World.HEIGHT+39);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true); //1)设置窗口可见  2)尽快调用paint()方法

        world.action(); //启动程序的执行
    }
}






















