package cn.tedu.submarine;
/** 得命接口 */
public interface EnemyLife {
    /** 得命 */
    public int getLife();
}
