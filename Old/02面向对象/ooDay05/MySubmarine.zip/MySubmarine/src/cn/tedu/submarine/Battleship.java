package cn.tedu.submarine;
/** 战舰:是海洋对象 */
public class Battleship extends SeaObject {
    private int life; //命
    /** 构造方法 */
    public Battleship(){
        super(66,26,260,124,20);
        life = 5;
    }

    /** 重写move()移动 */
    public void move(){
        //搁置
    }
}

















