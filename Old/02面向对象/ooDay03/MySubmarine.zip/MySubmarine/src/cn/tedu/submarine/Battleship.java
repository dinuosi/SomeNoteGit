package cn.tedu.submarine;
/** 战舰:是海洋对象 */
public class Battleship extends SeaObject {
    int life; //命
    /** 构造方法 */
    Battleship(){
        super(66,26,260,124,20);
        life = 5;
    }
}

















