package cn.tedu.submarine;
/** 整个游戏世界 */
public class World {
    public static void main(String[] args) {
        ObserveSubmarine[] oses = new ObserveSubmarine[3];
        TorpedoSubmarine[] tses = new TorpedoSubmarine[2];
        MineSubmarine[] mses = new MineSubmarine[3]; //水雷潜艇数组
        mses[0] = new MineSubmarine();
        mses[1] = new MineSubmarine();
        mses[2] = new MineSubmarine();
        for(int i=0;i<mses.length;i++){ //遍历所有水雷潜艇
            System.out.println(mses[i].x+","+mses[i].y); //输出每个水雷潜艇的x和y坐标
            mses[i].move(); //每个水雷潜艇移动
        }

        Torpedo[] ts = new Torpedo[2]; //鱼雷数组
        ts[0] = new Torpedo(100,200);
        ts[1] = new Torpedo(200,400);
        for(int i=0;i<ts.length;i++){
            System.out.println(ts[i].x+","+ts[i].y);
            ts[i].move();
        }
        Mine[] ms = new Mine[3];
        Bomb[] bs = new Bomb[2];

    }
}






















