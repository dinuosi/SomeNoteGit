package cn.tedu.submarine;
import java.util.Random;
/** 鱼雷潜艇 */
public class TorpedoSubmarine {
    int width;
    int height;
    int x;
    int y;
    int speed;
    /** 构造方法 */
    TorpedoSubmarine(){
        width = 64;
        height = 20;
        x = -width; //负的潜艇的宽
        Random rand = new Random(); //随机数对象
        y = rand.nextInt(479-height-150+1)+150; //150到(窗口高-潜艇高)之间的随机数
        speed = rand.nextInt(3)+1; //1到3之内的随机数
    }

    void move(){
        System.out.println("鱼雷潜艇移动");
    }
}














