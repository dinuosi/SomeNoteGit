package cn.tedu.submarine;
/** 整个游戏世界 */
public class World {
    public static void main(String[] args) {
        Battleship s = new Battleship();
        ObserveSubmarine os1 = new ObserveSubmarine();
        ObserveSubmarine os2 = new ObserveSubmarine();
        TorpedoSubmarine ts1 = new TorpedoSubmarine();
        TorpedoSubmarine ts2 = new TorpedoSubmarine();
        MineSubmarine ms1 = new MineSubmarine();
        MineSubmarine ms2 = new MineSubmarine();
        Torpedo t1 = new Torpedo(100,200);
        Torpedo t2 = new Torpedo(20,80);
        Mine m1 = new Mine(123,345);
        Mine m2 = new Mine(345,234);
        Bomb b1 = new Bomb(200,300);
        Bomb b2 = new Bomb(300,400);
        //最少输出4个对象的数据(一定要包括2个侦察潜艇的数据)
        System.out.println(s.width+","+s.height+","+s.x+","+s.y+","+s.speed+","+s.life);
        System.out.println(os1.width+","+os1.height+","+os1.x+","+os1.y+","+os1.speed);
        System.out.println(os2.width+","+os2.height+","+os2.x+","+os2.y+","+os2.speed);

    }
}






















