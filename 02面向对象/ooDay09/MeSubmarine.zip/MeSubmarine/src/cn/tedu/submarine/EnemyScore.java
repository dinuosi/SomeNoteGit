package cn.tedu.submarine;
/** 得分接口 */
public interface EnemyScore {
    /** 得分 */
    public int getScore();
}











