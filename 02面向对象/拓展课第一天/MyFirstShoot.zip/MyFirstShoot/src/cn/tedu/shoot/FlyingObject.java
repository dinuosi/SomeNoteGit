package cn.tedu.shoot;
import java.util.Random;
/** 飞行物 */
public class FlyingObject {
    protected int width;
    protected int height;
    protected int x;
    protected int y;

    /** 专门给小敌机、大敌机、小蜜蜂提供的 */
    //小敌机/大敌机/小蜜蜂的宽和高是不同的，意味着数据不能写死，需传参写活
    //小敌机/大敌机/小蜜蜂的x和y是相同的，意味着数据可以写死
    FlyingObject(int width,int height){
        this.width = width;
        this.height = height;
        Random rand = new Random();
        x = rand.nextInt(World.WIDTH-width+1); //0到(窗口宽-敌人宽)之内的随机数
        y = -height; //负的敌人的高
    }

    /** 专门给英雄机、天空、子弹提供的 */
    //英雄机/天空/子弹的宽/高/x/y都是不同的，意味着数据不能写死，需传参写活
    FlyingObject(int width,int height,int x,int y){
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
    }
}




















