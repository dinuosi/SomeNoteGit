package cn.tedu.shoot;
/** 天空 */
public class Sky extends FlyingObject {
    private int speed; //移动速度
    private int y1;    //第2张天空图片的y坐标
    /** 构造方法 */
    public Sky(){
        super(World.WIDTH,World.HEIGHT,0,0);
        speed = 1;
        y1 = -World.HEIGHT;
    }
}













