package cn.tedu.shoot;
/** 英雄机 */
public class Hero extends FlyingObject {
    private int life; //命数
    private int fire; //火力值
    /** 构造方法 */
    public Hero(){
        super(97,139,140,400);
        life = 5;
        fire = 0;
    }
}
















