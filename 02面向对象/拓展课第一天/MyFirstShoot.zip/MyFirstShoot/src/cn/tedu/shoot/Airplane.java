package cn.tedu.shoot;
/** 小敌机 */
public class Airplane extends FlyingObject {
    private int speed; //移动速度
    /** 构造方法 */
    public Airplane(){
        super(48,50);
        speed = 2;
    }
}













