package cn.tedu.shoot;
/** 大敌机 */
public class BigAirplane extends FlyingObject {
    private int speed; //移动速度
    /** 构造方法 */
    public BigAirplane(){
        super(66,89);
        speed = 2;
    }
}












