package cn.tedu.submarine;
/** 整个游戏世界  */
public class World {
    public static void main(String[] args) {
        Bomb[] bs = new Bomb[3]; //创建Bomb数组对象
        bs[0] = new Bomb(100,200); //创建Bomb对象
        bs[1] = new Bomb(123,345);
        bs[2] = new Bomb(200,300);
        bs[0].x = 111; //给第1个炸弹的x修改为111
        System.out.println(bs[1].width); //输出第2个炸弹的宽
        bs[2].move(); //第3个炸弹移动












        /*
        Battleship b = new Battleship();
        ObserveSubmarine os1 = new ObserveSubmarine();
        ObserveSubmarine os2 = new ObserveSubmarine();
        ObserveSubmarine os3 = new ObserveSubmarine();
        ObserveSubmarine os4 = new ObserveSubmarine();
        TorpedoSubmarine ts1 = new TorpedoSubmarine();
        TorpedoSubmarine ts2 = new TorpedoSubmarine();
        MineSubmarine ms1 = new MineSubmarine();
        MineSubmarine ms2 = new MineSubmarine();
        Mine m1 = new Mine(100,200);
        Mine m2 = new Mine(125,250);
        Bomb b1 = new Bomb(20,356);
        Bomb b2 = new Bomb(147,245);
        System.out.println(b.width+","+b.height+","+b.x+","+b.y+","+b.speed+","+b.life);
        System.out.println(os1.width+","+os1.height+","+os1.x+","+os1.y+","+os1.speed);
        System.out.println(os2.width+","+os2.height+","+os2.x+","+os2.y+","+os2.speed);
        System.out.println(os3.width+","+os3.height+","+os3.x+","+os3.y+","+os3.speed);
        System.out.println(os4.width+","+os4.height+","+os4.x+","+os4.y+","+os4.speed);
        */
    }
}

























