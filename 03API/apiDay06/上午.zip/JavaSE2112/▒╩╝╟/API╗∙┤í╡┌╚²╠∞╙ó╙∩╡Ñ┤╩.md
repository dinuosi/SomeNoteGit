# API基础第三天英语单词

1. Integer:整数
2. character:字符
3. equal:相等
4. point:点
5. file:文件
6. create:创建
7. delete:删除
8. directory:目录
9. make:做，造
10. parse:解析
11. max:最大值(maximum)
12. min:最小值(minimum)
13. read:读
14. write:写
15. hidden:隐藏
16. exists:存在

