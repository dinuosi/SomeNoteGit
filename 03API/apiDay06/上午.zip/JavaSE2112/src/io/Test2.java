package io;

/**
 * 实现简易记事本工具
 * 程序启动后，要求将控制台输入的每一行字符串都写入到文件note.txt中。
 * 当在控制台单独输入exit时，程序退出。
 */
public class Test2 {
}
