package homework.day04;

import java.io.IOException;

/**
 * 改正下面程序的错误
 * 
 * 程序实现的功能需求:复制一个文件
 * @author Xiloer
 *
 */
public class Test04 {
	public static void main(String[] args) throws IOException {
//		FileInputStream fis 
//	= new FileInputStream("test.txt");
//		FileInputStream fos
//		= new FIleInputStream("test_cp.txt");
//		
//		   int d;
//				while((d = fis.read())!=-1) {
//				fos.write(fis.read());
//					}
//				System.out.println("复制完毕!");
//					fis.close();
//	fos.close();
	}
}




