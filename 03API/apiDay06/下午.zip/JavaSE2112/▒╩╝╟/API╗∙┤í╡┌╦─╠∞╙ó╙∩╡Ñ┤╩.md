# API基础第四天英语单词

1. filter：过滤器
2. accept：接受
3. stream：流
4. input：输入
5. output：输出
6. write：写
7. read：读
8. close：关闭
9. copy：拷贝，复制
