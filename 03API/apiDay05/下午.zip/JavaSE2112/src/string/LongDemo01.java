package string;

public class LongDemo01 {
    public static void main(String[] args) {
        /*
         * current: 当前的
         * TimeMillis：时间毫秒数
         * 1970年元旦开始到现在的毫秒数
         */
        long now = System.currentTimeMillis();
        System.out.println(now);
    }
}
